export const heightPx = 350;

export const widthPx = 450;

export const rows = 5;

export const columns = 6;

export const maxDigit = 32;
