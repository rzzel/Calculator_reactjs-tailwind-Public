export interface AppState {
  displayValue: string;
  expression: string;
  isResult: boolean;
  error: string;
}
